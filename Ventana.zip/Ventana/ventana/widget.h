#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <pasoparam.h>
struct imagen {
    int id;
    QString archivo;
    QString nombre;
};

struct Nodo {
    imagen dato;
    Nodo* siguiente;
    Nodo* atras;
};
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void insertarNodo(Nodo *&primero, Nodo *&ultimo, imagen dato);
    void mostrarListaAsc(Nodo *primero);
    void mostrarListaDesc(Nodo *primero, Nodo *ultimo);
    void subirImagen(QString ruta,const QString &nombreArchivo, int id,int indiceImagenActual);
    void buscarNodo(QString ruta,Nodo *primero, int datoBuscado, int id);
private slots:
    void on_btncomprar_clicked();
    void on_btnsiguiente_clicked();
    void on_btnanterior_clicked();


private:
    Ui::Widget *ui;
    Nodo *primero=NULL;
    Nodo *ultimo=NULL;
    imagen Imagen;
    QString ImagenActual="";
    int imagenInicial=1;
    int imagenFinal=1;
    QString ruta;
    int bloqueImagenes=1;//primeras tres imagenes
    int indiceImagenActual=1;
};
#endif // WIDGET_H
