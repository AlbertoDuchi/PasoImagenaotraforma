#include "pasoparam.h"
#include "ui_pasoparam.h"
#include <QScreen>

PasoParam::PasoParam(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PasoParam)
{
    ui->setupUi(this);
    labelImagen = new QLabel(this);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(labelImagen);
    setLayout(layout);
}

PasoParam::~PasoParam()
{
    delete ui;
}

void PasoParam::mostrarImagen(const QString &rutaImagen)
{
    QPixmap pixmap(rutaImagen);
    QSize screenSize = QGuiApplication::primaryScreen()->availableSize();
    labelImagen->setPixmap(pixmap.scaled(screenSize.width(), screenSize.height(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    resize(pixmap.size());
    setWindowFlags(Qt::Window);
    setWindowTitle("Imagen Ampliada");
    setWindowModality(Qt::ApplicationModal);
    setAttribute(Qt::WA_DeleteOnClose);
    show();
}
