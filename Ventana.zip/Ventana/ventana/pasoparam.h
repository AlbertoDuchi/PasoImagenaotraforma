#ifndef PASOPARAM_H
#define PASOPARAM_H

#include <QWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QPixmap>

namespace Ui {
class PasoParam;
}

class PasoParam : public QWidget
{
    Q_OBJECT

public:
    explicit PasoParam(QWidget *parent = nullptr);
    ~PasoParam();
    void mostrarImagen(const QString &rutaImagen);

private:
    Ui::PasoParam *ui;
    QLabel *labelImagen;
};

#endif // PASOPARAM_H
