#include "widget.h"
#include "ui_widget.h"
#include "pasoparam.h" // Asegúrate de incluir pasoparam.h si no está incluido ya
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDir>
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowFlags(windowFlags() & ~Qt::WindowMinimizeButtonHint & ~Qt::WindowMaximizeButtonHint);
    setWindowTitle("Ejemplo");

    // directorio actual de trabajo
    QString directorioConcurrente = QDir::currentPath();

    // objeto con el directorio actual de trabajo
    QDir dir(directorioConcurrente);
    // directorio padre (anterior)
    dir.cdUp();

    ruta = dir.absolutePath() + "/";

    qDebug() << "Carpeta con unidad de disco:" << ruta;

    QString nombreArchivo = "imagenes.txt";
    QFile archivo(ruta + nombreArchivo);
    QTextStream io;

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", archivo.errorString());
    } else {
        io.setDevice(&archivo);
        int contador = 0;
        while (!io.atEnd()) {
            QString linea = io.readLine();
            QStringList datos = linea.split(",");
            Imagen.id = datos[0].toInt();
            Imagen.archivo = datos[1];
            Imagen.nombre = datos[2];

            insertarNodo(primero, ultimo, Imagen);
            qDebug() << datos[0] << " " << datos[1];
            contador++;
        }
        if (contador > 0) {
            imagenInicial = 1;
            imagenFinal = contador;
            for (int i = 1; i <= (bloqueImagenes * 3); i++) {
                if (i <= imagenFinal) {
                    buscarNodo(ruta, primero, imagenInicial++, i - 1);
                    if (i == 2) {
                        indiceImagenActual = 2;
                    }
                }
            }
            qDebug() << "Contador Actual: " << imagenInicial;
            //mostrarListaAsc(primero);
        }
        archivo.close();
    }
}

Widget::~Widget()
{
    delete ui;
}

void Widget::insertarNodo(Nodo *&primero, Nodo *&ultimo, imagen dato) {
    Nodo *nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    if (primero == nullptr) {
        primero = nuevoNodo;
        primero->siguiente = nullptr;
        primero->atras = nullptr;
        ultimo = primero;
    } else {
        ultimo->siguiente = nuevoNodo;
        nuevoNodo->siguiente = nullptr;
        nuevoNodo->atras = ultimo;
        ultimo = nuevoNodo;
    }
}

void Widget::mostrarListaAsc(Nodo *primero) {
    Nodo *actual = primero;
    if (primero != nullptr) {
        while (actual != nullptr) {
            qDebug() << actual->dato.id << " " << actual->dato.archivo << " " << actual->dato.nombre << "\n";
            actual = actual->siguiente;
        }
    } else {
        qDebug() << "La lista está vacía\n";
    }
}

void Widget::subirImagen(QString ruta, const QString &nombreArchivo, int id, int indiceImagenActual) {
    if (nombreArchivo.isEmpty()) {
        QMessageBox::information(this, "Aviso", "Error, no seleccionó una imagen");
        return;
    }
    if (id == 0) {
        QIcon icon(ruta + "imagenes/" + nombreArchivo);
        ui->btn1->setIcon(icon);
        ui->btn1->setIconSize(ui->btn1->size());
        ImagenActual = nombreArchivo;
    }
    if (id == 1) {
        QIcon icon(ruta + "imagenes/" + nombreArchivo);
        ui->btn2->setIcon(icon);
        ui->btn2->setIconSize(ui->btn2->size()); // Usar el tamaño de btn2
        ImagenActual = nombreArchivo;
    }
    if (id == 2) {
        QIcon icon(ruta + "imagenes/" + nombreArchivo);
        ui->btn3->setIcon(icon);
        ui->btn3->setIconSize(ui->btn3->size()); // Usar el tamaño de btn3
        ImagenActual = nombreArchivo;
    }
    if (id == -1) {
        QIcon icon(ruta + "imagenes/" + "SinImagen.png");
        ui->btn3->setIcon(icon);
        ui->btn3->setIconSize(ui->btn3->size()); // Usar el tamaño de btn3
        ImagenActual = nombreArchivo;
    }
}

void Widget::buscarNodo(QString ruta, Nodo *primero, int datoBuscado, int id) {
    Nodo *actual = primero;
    QString nombreArchivo;
    bool encontrado = false;

    if (primero != nullptr) {
        while (actual != nullptr && !encontrado) {
            if (actual->dato.id == datoBuscado) {
                nombreArchivo = actual->dato.archivo;
                indiceImagenActual = actual->dato.id;
                qDebug() << datoBuscado << " Dato encontrado\n";
                encontrado = true;
                qDebug() << "archivo:: " << ruta + nombreArchivo;
                subirImagen(ruta, nombreArchivo, id, indiceImagenActual);
            }
            actual = actual->siguiente;
        }
        if (!encontrado) {
            qDebug() << datoBuscado << " Dato no encontrado\n";
        }
    } else {
        qDebug() << "La lista se encuentra vacía\n";
        subirImagen(ruta, nombreArchivo, -1, indiceImagenActual);
    }
}

void Widget::on_btncomprar_clicked() {
    Nodo *actual = primero;
    QString nombreArchivo;
    bool encontrado = false;

    // Buscar la imagen asociada al btn2 en la lista
    if (primero != nullptr) {
        while (actual != nullptr && !encontrado) {
            if (actual->dato.id == indiceImagenActual-1) { // Cambiar '2' por el id correspondiente al btn2
                nombreArchivo = actual->dato.archivo;
                qDebug() << "Imagen asociada a btn2 encontrada: " << nombreArchivo;

                // Crear y mostrar la ventana de imagen en PasoParam
                PasoParam *ventanaImagen = new PasoParam();
                ventanaImagen->mostrarImagen(ruta + "imagenes/" + nombreArchivo);
                ventanaImagen->show();

                encontrado = true;
            }
            actual = actual->siguiente;
        }
        if (!encontrado) {
            qDebug() << "Imagen asociada a btn2 no encontrada";
        }
    } else {
        qDebug() << "La lista se encuentra vacía";
    }
}

void Widget::on_btnsiguiente_clicked() {
    bloqueImagenes += 1;
    int i;
    qDebug() << "inicio: " << imagenInicial << " Fin: " << imagenFinal << " Bloque" << bloqueImagenes;
    if (imagenFinal > 0 and bloqueImagenes <= imagenFinal) {
        for (i = imagenInicial; i <= (bloqueImagenes * 3); i++) {
            buscarNodo(ruta, primero, i, i - imagenInicial);
        }
        imagenInicial = i;
        qDebug() << "Contador Actual1: " << imagenInicial;
    } else {
        if (bloqueImagenes > 1) {
            bloqueImagenes -= 1;
        }
    }
}

void Widget::on_btnanterior_clicked() {
    if (bloqueImagenes > 1) {
        bloqueImagenes--;
        imagenInicial = 1 + (bloqueImagenes - 1) * 3; // Calcular la nueva imagen inicial

        // Mostrar las imágenes del nuevo bloque
        for (int i = imagenInicial; i <= imagenInicial + 2 && i <= imagenFinal; i++) {
            buscarNodo(ruta, primero, i, i - imagenInicial);
        }

        qDebug() << "Contador Actual al retroceder: " << imagenInicial;
    } else {
        qDebug() << "Ya estás en el primer bloque de imágenes.";
    }
}
