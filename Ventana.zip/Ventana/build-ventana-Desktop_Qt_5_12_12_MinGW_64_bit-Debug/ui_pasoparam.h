/********************************************************************************
** Form generated from reading UI file 'pasoparam.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PASOPARAM_H
#define UI_PASOPARAM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PasoParam
{
public:

    void setupUi(QWidget *PasoParam)
    {
        if (PasoParam->objectName().isEmpty())
            PasoParam->setObjectName(QString::fromUtf8("PasoParam"));
        PasoParam->resize(400, 300);

        retranslateUi(PasoParam);

        QMetaObject::connectSlotsByName(PasoParam);
    } // setupUi

    void retranslateUi(QWidget *PasoParam)
    {
        PasoParam->setWindowTitle(QApplication::translate("PasoParam", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PasoParam: public Ui_PasoParam {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PASOPARAM_H
