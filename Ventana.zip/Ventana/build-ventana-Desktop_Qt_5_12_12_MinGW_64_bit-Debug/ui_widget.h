/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    QPushButton *btnsiguiente;
    QPushButton *btnanterior;
    QPushButton *btncomprar;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(891, 600);
        btn1 = new QPushButton(Widget);
        btn1->setObjectName(QString::fromUtf8("btn1"));
        btn1->setGeometry(QRect(110, 140, 211, 261));
        btn2 = new QPushButton(Widget);
        btn2->setObjectName(QString::fromUtf8("btn2"));
        btn2->setGeometry(QRect(330, 120, 231, 321));
        btn3 = new QPushButton(Widget);
        btn3->setObjectName(QString::fromUtf8("btn3"));
        btn3->setGeometry(QRect(570, 140, 211, 261));
        btnsiguiente = new QPushButton(Widget);
        btnsiguiente->setObjectName(QString::fromUtf8("btnsiguiente"));
        btnsiguiente->setGeometry(QRect(800, 210, 61, 111));
        btnanterior = new QPushButton(Widget);
        btnanterior->setObjectName(QString::fromUtf8("btnanterior"));
        btnanterior->setGeometry(QRect(30, 230, 61, 111));
        btncomprar = new QPushButton(Widget);
        btncomprar->setObjectName(QString::fromUtf8("btncomprar"));
        btncomprar->setGeometry(QRect(410, 470, 93, 28));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        btn1->setText(QString());
        btn2->setText(QString());
        btn3->setText(QString());
        btnsiguiente->setText(QApplication::translate("Widget", ">", nullptr));
        btnanterior->setText(QApplication::translate("Widget", "<", nullptr));
        btncomprar->setText(QApplication::translate("Widget", "Comprar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
